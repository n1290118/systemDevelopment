
public abstract class Node {
	protected String name;
	public abstract void printInfo(String prefix);
	public abstract int getSize();
}
