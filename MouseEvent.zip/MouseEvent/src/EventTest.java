
public class EventTest {

	public static void main(String[] args) {
		MyFrame frame = new MyFrame(); 	//MyFrameのｵﾌﾞｼﾞｪｸﾄ生成
		frame.setVisible(true); 			//MyFrameのsetVisibleを呼び出して、
													//ウィンドウを表示
	}

}
