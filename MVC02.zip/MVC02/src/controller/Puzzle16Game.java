package controller;

import view.*;

public class Puzzle16Game {

	public static void main(String[] args) {

		Puzzle16GameFrame frame=new Puzzle16GameFrame();
		frame.setVisible(true);
	}

}
